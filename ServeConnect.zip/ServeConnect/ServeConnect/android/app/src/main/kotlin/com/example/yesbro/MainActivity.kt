package com.example.yesbro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
