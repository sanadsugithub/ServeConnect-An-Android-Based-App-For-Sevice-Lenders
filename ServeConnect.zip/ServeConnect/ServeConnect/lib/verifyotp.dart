import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class OtpAuthenticationPage extends StatefulWidget {
  final String phoneNumber;

  const OtpAuthenticationPage({Key? key, required this.phoneNumber})
      : super(key: key);

  @override
  _OtpAuthenticationPageState createState() => _OtpAuthenticationPageState();
}

class _OtpAuthenticationPageState extends State<OtpAuthenticationPage> {
  final TextEditingController _otpController = TextEditingController();
  String verificationId = "";
  bool verifying = false; // Added for showing a loading indicator

  @override
  void initState() {
    super.initState();
    _verifyPhoneNumber();
  }

  void _verifyPhoneNumber() async {
    setState(() {
      verifying = true; // Show loading indicator
    });
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: widget.phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async {
        await FirebaseAuth.instance.signInWithCredential(credential);
        Navigator.pop(context,
            true); // Navigate back indicating successful authentication
      },
      verificationFailed: (FirebaseAuthException e) {
        setState(() {
          verifying = false; // Hide loading indicator
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Verification failed: ${e.message}'),
          ),
        );
      },
      codeSent: (String verificationId, int? resendToken) {
        setState(() {
          verifying = false;
          this.verificationId = verificationId;
        });
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        // Handle timeout
        setState(() {
          verifying = false;
        });
      },
    );
  }

  void _verifyOtp() async {
    PhoneAuthCredential credential = PhoneAuthProvider.credential(
        verificationId: verificationId, smsCode: _otpController.text);
    setState(() {
      verifying = true;
    });
    try {
      await FirebaseAuth.instance.signInWithCredential(credential);
      Navigator.pop(context, true);
    } catch (e) {
      setState(() {
        verifying = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Authentication failed: $e'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('OTP Authentication'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Enter OTP sent to ${widget.phoneNumber}',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 20),
            TextFormField(
              controller: _otpController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Enter OTP',
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: verifying ? null : _verifyOtp,
              child:
                  verifying ? CircularProgressIndicator() : Text('Verify OTP'),
            ),
          ],
        ),
      ),
    );
  }
}
