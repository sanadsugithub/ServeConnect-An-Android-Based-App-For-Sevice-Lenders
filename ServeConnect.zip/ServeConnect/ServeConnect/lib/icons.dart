import 'package:flutter/material.dart';
import 'location.dart'; // Import the LocationPage if it exists

class Service {
  final String name;
  final IconData icon;

  Service({required this.name, required this.icon});
}

class IconsPage extends StatelessWidget {
  const IconsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<Service> services = [
      Service(name: 'Plumbing', icon: Icons.plumbing),
      Service(name: 'Carpentry', icon: Icons.handyman),
      Service(name: 'Beautician', icon: Icons.spa),
      Service(name: 'Cleaner', icon: Icons.cleaning_services),
      Service(name: 'Mechanic', icon: Icons.car_repair),
      Service(name: 'Laundry', icon: Icons.local_laundry_service),
      Service(name: 'Baby Sitting', icon: Icons.child_care), // New service
      Service(name: 'Tutoring', icon: Icons.menu_book), // New service
      Service(name: 'Catering', icon: Icons.food_bank), // New service
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Services'),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        padding: EdgeInsets.all(16.0),
        childAspectRatio: 1.2,
        mainAxisSpacing: 16.0,
        crossAxisSpacing: 16.0,
        children: services.map((service) {
          return Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          LocationPage(serviceName: service.name)),
                );
              },
              borderRadius: BorderRadius.circular(12),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(service.icon, size: 48),
                  SizedBox(height: 8),
                  Text(
                    service.name,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
