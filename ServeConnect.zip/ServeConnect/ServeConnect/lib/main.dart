import 'package:flutter/material.dart';
import 'package:yesbro/intro.dart';

void main() {
  runApp(MaterialApp(
    home: IntroPage(),
  ));
}
