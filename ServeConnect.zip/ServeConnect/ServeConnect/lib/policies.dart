import 'package:flutter/material.dart';
import 'icons.dart'; // Import the IconsPage if it exists

class InstructionSet extends StatefulWidget {
  const InstructionSet({Key? key}) : super(key: key);

  @override
  State<InstructionSet> createState() => _InstructionSetState();
}

class _InstructionSetState extends State<InstructionSet> {
  bool _isChecked = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Instructions'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Please read the following instructions carefully:',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: SingleChildScrollView(
                child: Text(
                  'User Registration: Ensure users can easily register with their email or phone number. Clearly outline the registration process and the information required. Provide options for account recovery and secure password management.\n\n'
                  'Service Selection: Offer a clear and intuitive interface for users to browse and select services. Provide detailed descriptions, pricing, and any associated terms or conditions for each service offered.\n\n'
                  'Payment and Billing: Clearly communicate payment methods accepted and ensure secure payment processing. Provide transparent pricing, including any additional fees or charges. Outline billing cycles, refund policies, and procedures for resolving payment disputes.\n\n'
                  'Privacy and Data Security: Prioritize user privacy by clearly stating how personal data is collected, used, and protected. Implement robust security measures to safeguard user information. Provide options for users to control their privacy settings and manage their data.\n\n'
                  'Customer Support: Offer accessible customer support channels, such as live chat, email, or phone support, to address user inquiries and concerns promptly. Provide comprehensive FAQs and user guides to assist users in navigating the app and resolving common issues. Ensure a responsive and empathetic approach to customer feedback and complaints.',
                  style: TextStyle(
                    fontSize: 16,
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),
            CheckboxListTile(
              title: Text(
                'I have read and understood the instructions.',
                style: TextStyle(
                  fontSize: 16,
                ),
              ),
              value: _isChecked,
              onChanged: (bool? value) {
                if (value != null && value) {
                  _navigateToIconsPage(context);
                }
                setState(() {
                  _isChecked = value!;
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  void _navigateToIconsPage(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => IconsPage()),
    );
  }
}
