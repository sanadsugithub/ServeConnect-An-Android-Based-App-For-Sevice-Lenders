import 'package:flutter/material.dart';
import 'policies.dart';

class OtpForm extends StatelessWidget {
  final String phoneNumber;

  const OtpForm({Key? key, required this.phoneNumber}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('OTP Verification'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'OTP Verification Page',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Navigate to PoliciesPage
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => InstructionSet(),
                  ),
                );
              },
              child: Text('Continue to Policies'),
            ),
          ],
        ),
      ),
    );
  }
}
