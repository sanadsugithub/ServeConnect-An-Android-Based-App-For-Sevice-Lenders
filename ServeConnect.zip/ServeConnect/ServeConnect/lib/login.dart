import 'package:flutter/material.dart';
import 'signup.dart'; // Import your SignUp page

class LoginPage extends StatefulWidget {
  final String? role; // Add role parameter

  LoginPage({Key? key, this.role}) : super(key: key); // Update constructor

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  late TextEditingController _usernameController;
  late TextEditingController _passwordController;
  bool _firstTimeUser = false; // Add boolean for first-time user

  @override
  void initState() {
    super.initState();
    _usernameController = TextEditingController();
    _passwordController = TextEditingController();
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login Page'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Welcome to the Login Page!',
              style: TextStyle(fontSize: 18.0),
            ),
            if (widget.role != null) // Check if role is not null
              Text(
                'You selected role: ${widget.role}',
                style: TextStyle(fontSize: 18.0),
              ),
            SizedBox(height: 20.0),
            CheckboxListTile(
              title: Text('First-time user?'),
              value: _firstTimeUser,
              onChanged: (value) {
                setState(() {
                  _firstTimeUser = value!;
                  // Check if the checkbox is checked
                  // If checked, navigate to signup page
                  if (_firstTimeUser) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SignUpPage()),
                    );
                  }
                });
              },
            ),
            SizedBox(height: 10.0),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: TextField(
                controller: _usernameController,
                decoration: InputDecoration(
                  labelText: 'Username',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            SizedBox(height: 10.0),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: TextField(
                controller: _passwordController,
                decoration: InputDecoration(
                  labelText: 'Password',
                  border: OutlineInputBorder(),
                ),
                obscureText: true, // Hide password text
              ),
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                // Check if username or password is empty
                if (_usernameController.text.isEmpty ||
                    _passwordController.text.isEmpty) {
                  // Display an error message if username or password is empty
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Please enter both username and password.'),
                    ),
                  );
                } else {
                  // Navigate to the instruction set page if username and password are provided
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => SignUpPage()),
                  );
                }
              },
              child: Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}
