import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:yesbro/verifyotp.dart';
import 'otp.dart'; // Assuming this is the correct import
import 'policies.dart'; // Assuming this is the correct import

class SignUpPage extends StatelessWidget {
  SignUpPage({Key? key}) : super(key: key);

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();

  Future<void> _signUpWithEmail(BuildContext context) async {
    try {
      UserCredential userCredential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailController.text,
        password: _passwordController.text,
      );
      // Navigate to next page after successful signup, for example, InstructionSet
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => InstructionSet()),
      );
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        print('The password provided is too weak.');
        // Handle weak password error
      } else if (e.code == 'email-already-in-use') {
        print('The account already exists for that email.');
        // Handle existing email error
      }
    } catch (e) {
      print(e);
      // Handle other errors
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  hintText: 'Enter your email',
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              SizedBox(height: 16),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  hintText: 'Enter your password',
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => _signUpWithEmail(context),
                child: Text('Sign up with Email'),
              ),
              SizedBox(height: 16),
              TextField(
                controller: _phoneNumberController,
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(
                  hintText: 'Enter your phone number',
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  // Ensure valid phone number is entered
                  if (_phoneNumberController.text.isNotEmpty) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => OtpAuthenticationPage(
                          phoneNumber: _phoneNumberController.text,
                        ),
                      ),
                    );
                  } else {
                    // Show error or prompt user to enter phone number
                    print('Please enter a valid phone number');
                  }
                },
                child: Text('Sign up with Phone Number'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
