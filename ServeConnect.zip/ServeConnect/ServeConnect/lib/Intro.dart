import 'dart:async';
import 'package:flutter/material.dart';
import 'package:yesbro/login.dart'; // Import your RoleSelectionPage
class IntroPage extends StatefulWidget {
  @override
  _IntroPageState createState() => _IntroPageState();
}

class _IntroPageState extends State<IntroPage> {
  @override
  void initState() {
    super.initState();
    Timer(
      Duration(seconds: 3), 
      () {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => LoginPage(), // Navigate to RoleSelectionPage
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.home_repair_service_rounded, 
              size: 48.0,
              color: Colors.blue, 
            ),
            SizedBox(height: 16.0),
            Text(
              'Servconnect',
              style: TextStyle(
                fontSize: 32.0, // Adjust the font size as needed
                fontWeight: FontWeight.bold,
                fontFamily: 'great vibes', // Use a custom font if available
                // Add more styling properties if needed
              ),
            ),
          ],
        ),
      ),
    );
  }
}
